/*
 * alfsbl_defines.h
 *
 *  Created on: May 24, 2022
 *      Author: qsxu
 */

#ifndef ALFSBL_DEFINES_H_
#define ALFSBL_DEFINES_H_

#define CPU_RPU_64

#endif /* ALFSBL_DEFINES_H_ */
