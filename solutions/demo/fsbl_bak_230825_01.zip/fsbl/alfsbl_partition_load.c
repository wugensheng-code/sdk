/*
 * alfsbl_partition_load.c
 *
 *  Created on: May 18, 2022
 *      Author: qsxu
 */
#include <alfsbl_secure.h>
#include <stdio.h>
#include <stdint.h>
#include "demosoc.h"
#include "alfsbl_misc.h"
#include "alfsbl_err_code.h"
#include "alfsbl_hw.h"
#include "alfsbl_data.h"
#include "alfsbl_boot.h"
#include "alfsbl_partition_load.h"

extern uint8_t  ReadBuffer[READ_BUFFER_SIZE];



static uint32_t AlFsbl_PartitionHeaderValidation(AlFsblInfo *FsblInstancePtr, uint32_t PartitionIdx, SecureInfo *pSecureInfo);

static uint32_t AlFsbl_LoadPsPartition(AlFsblInfo *FsblInstancePtr, SecureInfo *pSecureInfo, uint32_t PartitionIdx);

static uint32_t AlFsbl_LoadPlPartition(AlFsblInfo *FsblInstancePtr, SecureInfo *pSecureInfo, uint32_t PartitionIdx);

static uint32_t AlFsbl_BitstreamDataTransfer(AlFsblInfo *FsblInstancePtr, SecureInfo *pSecureInfo,
		                                     uint32_t PartitionIdx, uint32_t BufferAddr, uint32_t BlockSizeMax);


static __attribute__((noinline)) uint32_t AlFsbl_CheckPlInitDone(void);
static uint32_t ALFsbl_BitStreamProgDone(void);

static void     AlFsbl_PrintPartitionHeaderInfo(AlFsbl_PartitionHeader *PtHdr);

extern uint8_t  ReadBuffer[READ_BUFFER_SIZE];
extern SecureInfo FsblSecInfo;
extern uint8_t  AuthBuffer[ALFSBL_AUTH_BUFFER_SIZE];

uint32_t AlFsbl_PartitionLoad(AlFsblInfo *FsblInstancePtr, uint32_t PartitionIdx)
{
	uint32_t Status;
	uint32_t DestDev;

	/// todo: restart wdt

//	/// release pl reset
//	if(FsblInstancePtr->ResetReason == FSBL_SYSTEM_RESET) {
//		REG32(SYSCTRL_S_GLOBAL_SRSTN) = REG32(SYSCTRL_S_GLOBAL_SRSTN) | (SYSCTRL_S_GLOBAL_SRSTN_MSK_GLB_PL_SRST);
//	}

	/// partition header validation
	Status = AlFsbl_PartitionHeaderValidation(FsblInstancePtr, PartitionIdx, &FsblSecInfo);
	if(ALFSBL_SUCCESS_NOT_PARTITION_OWNER == Status) {
		Status = ALFSBL_SUCCESS;
		goto END;
	}
	else if(ALFSBL_SUCCESS != Status) {
		goto END;
	}

	DestDev = FsblInstancePtr->ImageHeader.PartitionHeader[PartitionIdx].PartitionAttribute & ALIH_PH_ATTRIB_DEST_DEV_MASK;

	if(DestDev == ALIH_PH_ATTRIB_DEST_DEV_PS) {
		printf("loading ps partition...\r\n");
		Status = AlFsbl_LoadPsPartition(FsblInstancePtr, &FsblSecInfo, PartitionIdx);
		if(Status != ALFSBL_SUCCESS) {
			goto END;
		}
	}
	else if(DestDev == ALIH_PH_ATTRIB_DEST_DEV_PL) {
		if(FsblInstancePtr->ResetReason == FSBL_PS_ONLY_RESET) {
			printf("ps only reset, no need to load pl partition\r\n");
			Status = ALFSBL_SUCCESS;
			goto END;
		}
		printf("loading pl partition...\r\n");
		Status = AlFsbl_LoadPlPartition(FsblInstancePtr, &FsblSecInfo, PartitionIdx);
	}
	else {
		/**do nothing**/
	}
END:
	return Status;
}


static uint32_t AlFsbl_PartitionHeaderValidation(AlFsblInfo *FsblInstancePtr, uint32_t PartitionIdx, SecureInfo *pSecureInfo)
{
	uint32_t Status = 0;
	AlFsbl_PartitionHeader *PtHdr;
	uint32_t PtAttrHashType;
	uint32_t PtAttrAuthType;
	uint32_t PtAttrEncType;
	uint32_t DestCpu;
	uint32_t DestDev;
	uint32_t EfuseCtrl;
	uint32_t PartitionAttr;

	EfuseCtrl = REG32(EFUSE_SEC_CTRL);
	PtHdr = &(FsblInstancePtr->ImageHeader.PartitionHeader[PartitionIdx]);
	PartitionAttr = PtHdr->PartitionAttribute;

	/// check checksum of partition header
	printf("Partition Header Checksum: 0x%08x\r\n", PtHdr->PartiHdrChecksum);
	Status = AlFsbl_ChecksumCheck(
				(uint8_t *)(PtHdr),
				sizeof(AlFsbl_PartitionHeader) - 4,   /// the last word in PartitionHeader is checksum
				PtHdr->PartiHdrChecksum);
	if(Status != ALFSBL_SUCCESS) {
		goto END;
	}

	/// check partition owner
	if((PartitionAttr & ALIH_PH_ATTRIB_PART_OWNER_MASK) != ALIH_PH_ATTRIB_PART_OWNER_FSBL) {
		printf("Partition owner: %08x\r\n", PtHdr->PartitionAttribute & ALIH_PH_ATTRIB_PART_OWNER_MASK);
		printf("Partition owner not fsbl, skip it, partition num: %d\r\n", PartitionIdx);
		Status = ALFSBL_SUCCESS_NOT_PARTITION_OWNER;
		goto END;
	}


	/// check hash type
	PtAttrHashType = PartitionAttr & ALIH_PH_ATTRIB_HASH_TYPE_MASK;
	printf("Hash Type: 0x%08x\r\n", PtAttrHashType);
	if(PtAttrHashType == ALIH_PH_ATTRIB_HASH_TYPE_NONE) {
		pSecureInfo->HashType = OP_HASH_NONE;
		printf("Hash NOT enabled.\r\n");
	}
	else if(PtAttrHashType == ALIH_PH_ATTRIB_HASH_TYPE_SHA256) {
		pSecureInfo->HashType = OP_HASH_SHA256;
		printf("Hash SHA256.\r\n");
	}
	else if(PtAttrHashType == ALIH_PH_ATTRIB_HASH_TYPE_SM3) {
		pSecureInfo->HashType = OP_HASH_SM3;
		printf("Hash SM3.\r\n");
	}
	else {
		printf("Invalid Hash Type\r\n");
		Status = ALFSBL_INVALID_HASH_TYPE;
		goto END;
	}

	/// check authentication type
	PtAttrAuthType = PartitionAttr & ALIH_PH_ATTRIB_AUTH_TYPE_MASK;
	printf("Auth Type       : %x\r\n", PtAttrAuthType);
	printf("Efuse Auth Type : %x\r\n", EfuseCtrl & EFUSE_AUTH_TYPE_MASK);
	if((EfuseCtrl & EFUSE_AUTH_TYPE_MASK) == EFUSE_AUTH_TYPE_HEADER_SET) {
		if(PtAttrAuthType == ALIH_PH_ATTRIB_AUTH_TYPE_NONE) {
			pSecureInfo->AuthType = OP_AUTH_NONE;
			printf("Authentication NOT enabled...\r\n");
		}
		else if(PtAttrAuthType == ALIH_PH_ATTRIB_AUTH_TYPE_ECC256) {
			pSecureInfo->AuthType = OP_AUTH_ECC256;
			pSecureInfo->HashType = OP_HASH_SHA256;
			printf("Authentication ECC256\r\n");
		}
		else if(PtAttrAuthType == ALIH_PH_ATTRIB_AUTH_TYPE_SM2) {
			pSecureInfo->AuthType = OP_AUTH_SM2;
			pSecureInfo->HashType = OP_HASH_SM3;
			printf("Authentication SM2\r\n");
		}
	}
	else if(((EfuseCtrl & EFUSE_AUTH_TYPE_MASK) == EFUSE_AUTH_TYPE_ECC256) &&
			(PtAttrAuthType == ALIH_PH_ATTRIB_AUTH_TYPE_ECC256)) {
		pSecureInfo->AuthType = OP_AUTH_ECC256;
		pSecureInfo->HashType = OP_HASH_SHA256;
		printf("Authentication ECC256\r\n");
	}
	else if(((EfuseCtrl & EFUSE_AUTH_TYPE_MASK) == EFUSE_AUTH_TYPE_SM2) &&
			(PtAttrAuthType == ALIH_PH_ATTRIB_AUTH_TYPE_SM2)) {
		pSecureInfo->AuthType = OP_AUTH_SM2;
		pSecureInfo->HashType = OP_HASH_SM3;
		printf("Authentication SM2\r\n");
	}
	else {
		printf("Auth type not match efuse set...\r\n");
		Status = ALFSBL_AUTHTYPE_NOT_MATCH_EFUSE;
		goto END;
	}

	/// check encryption type
	PtAttrEncType  = PartitionAttr & ALIH_PH_ATTRIB_ENC_TYPE_MASK;
	printf("Enc Type       : %x\r\n", PtAttrEncType);
	printf("Efuse Enc Type : %x\r\n", EfuseCtrl & EFUSE_ENC_TYPE_MASK);
	if((EfuseCtrl & EFUSE_ENC_TYPE_MASK) == EFUSE_ENC_TYPE_HEADER_SET) {
		if(PtAttrEncType == ALIH_PH_ATTRIB_ENC_TYPE_NONE) {
			pSecureInfo->EncType = OP_ENCRYPT_NONE;
			printf("Encrypt NOT enabled.\r\n");
		}
		else if(PtAttrEncType == ALIH_PH_ATTRIB_ENC_TYPE_AES256) {
			pSecureInfo->EncType = OP_ENCRYPT_AES256;
			printf("Encrypt AES256.\r\n");
		}
		else if(PtAttrEncType == ALIH_PH_ATTRIB_ENC_TYPE_SM4) {
			pSecureInfo->EncType = OP_ENCRYPT_SM4;
			printf("Encrypt SM4.\r\n");
		}
	}
	else if(((EfuseCtrl & EFUSE_ENC_TYPE_MASK) == EFUSE_ENC_TYPE_AES256) &&
			(PtAttrEncType == ALIH_PH_ATTRIB_ENC_TYPE_AES256)) {
		pSecureInfo->EncType = OP_ENCRYPT_AES256;
		printf("Encrypt AES256.\r\n");
	}
	else if(((EfuseCtrl & EFUSE_ENC_TYPE_MASK) == EFUSE_ENC_TYPE_SM4) &&
			(PtAttrEncType == ALIH_PH_ATTRIB_ENC_TYPE_SM4)) {
		pSecureInfo->EncType = OP_ENCRYPT_SM4;
		printf("Encrypt SM4.\r\n");
	}
	else {
		printf("Encrypt type not match efuse set...\r\n");
		Status = ALFSBL_ENCTYPE_NOT_MATCH_EFUSE;
		goto END;
	}

	/// check enc type, auth type, hash type match
	if((pSecureInfo->EncType == OP_ENCRYPT_SM4) &&
	   ((pSecureInfo->HashType == OP_HASH_SHA256) || (pSecureInfo->AuthType == OP_AUTH_ECC256))) {
		Status = ALFSBL_SEC_TYPE_MISMACTCH;
		goto END;
	}
	else if((pSecureInfo->EncType == OP_ENCRYPT_AES256) &&
	        ((pSecureInfo->HashType == OP_HASH_SM3) || (pSecureInfo->AuthType == OP_AUTH_SM2))) {
		Status = ALFSBL_SEC_TYPE_MISMACTCH;
		goto END;
	}
	else if(((pSecureInfo->HashType == OP_HASH_SM3) && (pSecureInfo->AuthType == OP_AUTH_ECC256)) ||
		    ((pSecureInfo->HashType == OP_HASH_SHA256) && (pSecureInfo->AuthType == OP_AUTH_SM2))) {
		Status = ALFSBL_SEC_TYPE_MISMACTCH;
		goto END;
	}

	/// check destination cpu
	DestCpu = PartitionAttr & ALIH_PH_ATTRIB_DEST_CPU_MASK;
	printf("destination cpu: 0x%08x\r\n", DestCpu);
	if(DestCpu != ALIH_PH_ATTRIB_DEST_CPU_RPU &&
	   DestCpu != ALIH_PH_ATTRIB_DEST_CPU_APU0 &&
	   DestCpu != ALIH_PH_ATTRIB_DEST_CPU_APU1) {
		Status = ALFSBL_INVALID_DEST_CPU;
		goto END;
	}

	/// check destination device
	DestDev = PartitionAttr & ALIH_PH_ATTRIB_DEST_DEV_MASK;
	printf("destination dev: 0x%08x\r\n", DestDev);
	if(DestDev != ALIH_PH_ATTRIB_DEST_DEV_PS &&
	   DestDev != ALIH_PH_ATTRIB_DEST_DEV_PL) {
		Status = ALFSBL_INVALID_DEST_DEV;
		goto END;
	}

	/// check partion length
	printf("check partition length: \r\n");
	if((PtHdr->PartitionLen < PtHdr->ExtractedPartitionLen) ||
	   (PtHdr->TotalPartitionLen < PtHdr->ExtractedPartitionLen)) {
		Status = ALFSBL_INVALID_PARTITION_LENGTH;
		goto END;
	}
	if((!PtAttrAuthType) && (!PtAttrHashType)) {
		if(PtHdr->PartitionLen != PtHdr->TotalPartitionLen) {
			Status = ALFSBL_INVALID_PARTITION_LENGTH;
			goto END;
		}
	}
	else {
		if(PtHdr->PartitionLen >= PtHdr->TotalPartitionLen) {
			Status = ALFSBL_INVALID_PARTITION_LENGTH;
			goto END;
		}
	}
	FsblSecInfo.DataLength = PtHdr->PartitionLen;

	/// check load and exec address
	if((AL9000_DDR1_BASE_ADDR <= PtHdr->DestLoadAddr) && (PtHdr->DestLoadAddr < AL9000_DDR1_BASE_ADDR + AL9000_DDR1_BYTE_LENGTH)) {
		// correct, do nothing
	}
	else if((AL9000_DDR2_BASE_ADDR <= PtHdr->DestLoadAddr) && (PtHdr->DestLoadAddr < AL9000_DDR2_BASE_ADDR + AL9000_DDR2_BYTE_LENGTH)) {
		// correct, do nothing
	}
	else if((AL9000_RPU_ITCM_BASE_ADDR <= PtHdr->DestLoadAddr) && (PtHdr->DestLoadAddr < AL9000_RPU_ITCM_BASE_ADDR + AL9000_RPU_ITCM_BYTE_LENGTH)) {
		// correct, do nothing
	}
	else if((AL9000_RPU_DTCM_BASE_ADDR <= PtHdr->DestLoadAddr) && (PtHdr->DestLoadAddr < AL9000_RPU_DTCM_BASE_ADDR + AL9000_RPU_ITCM_BYTE_LENGTH)) {
		// correct, do nothing
	}
	else if((AL9000_OCM_BASE_ADDR <= PtHdr->DestLoadAddr) && (PtHdr->DestLoadAddr < AL9000_OCM_BASE_ADDR + AL9000_OCM_BYTE_LENGTH)) {
		// correct, do nothing
	}
	else if ((PtHdr->DestLoadAddr == CSU_PCAP_WR_STREAM) || (PtHdr->DestLoadAddr == CSU_PCAP_CSULOCAL_WR_STREAM)) {
		// correct, do nothing
	}
	else {
		Status = ALFSBL_INVALID_LOAD_ADDR;
	}

	if(PtHdr->DestExecAddr == 0xFFFFFFFF) {
		// correct, do nothing, it is a none handoff ps partition
	}
	else if((AL9000_DDR1_BASE_ADDR <= PtHdr->DestExecAddr) && (PtHdr->DestExecAddr < AL9000_DDR1_BASE_ADDR + AL9000_DDR1_BYTE_LENGTH)) {
		// correct, do nothing
	}
	else if((AL9000_DDR2_BASE_ADDR <= PtHdr->DestExecAddr) && (PtHdr->DestExecAddr < AL9000_DDR2_BASE_ADDR + AL9000_DDR2_BYTE_LENGTH)) {
		// correct, do nothing
	}
	else if((AL9000_RPU_ITCM_BASE_ADDR <= PtHdr->DestExecAddr) && (PtHdr->DestExecAddr < AL9000_RPU_ITCM_BASE_ADDR + AL9000_RPU_ITCM_BYTE_LENGTH)) {
		// correct, do nothing
	}
	else if((AL9000_OCM_BASE_ADDR <= PtHdr->DestExecAddr) && (PtHdr->DestExecAddr < AL9000_OCM_BASE_ADDR + AL9000_OCM_BYTE_LENGTH)) {
		// correct, do nothing
	}
	else {
		Status = ALFSBL_INVALID_EXEC_ADDR;
	}



END:
    AlFsbl_PrintPartitionHeaderInfo(PtHdr);
	return Status;
}


static uint32_t AlFsbl_LoadPsPartition(AlFsblInfo *FsblInstancePtr, SecureInfo *pSecureInfo, uint32_t PartitionIdx)
{
	AlFsbl_PartitionHeader *PtHdr;

	uint32_t Status = 0;
	uint8_t  HashBuffer[32];
	uint32_t HashByteLen;
	uint32_t DestCpu;
	uint32_t HandoffNum;
	uint64_t SrcAddress;
	uint64_t LoadAddress;
	uint32_t Length;
	uint32_t PartitionAcOffset;
	PTRSIZE  ImageOffsetAddress;
	uint8_t  PartitionAc[ALFSBL_AUTH_BUFFER_SIZE];

	int i;
	uint32_t *ocmptr = NULL;

	PtHdr = &(FsblInstancePtr->ImageHeader.PartitionHeader[PartitionIdx]);
	DestCpu = PtHdr->PartitionAttribute & ALIH_PH_ATTRIB_DEST_CPU_MASK;
	ImageOffsetAddress = FsblInstancePtr->ImageOffsetAddress;

	SrcAddress = FsblInstancePtr->ImageOffsetAddress + PtHdr->PartitionOffset;
	LoadAddress = PtHdr->DestLoadAddr;
	Length = PtHdr->PartitionLen;

	printf("partition src address      : 0x%08x\r\n", SrcAddress);
	printf("partition load dest address: 0x%08x\r\n", LoadAddress);
	printf("partition length           : 0x%08x\r\n", Length);

	pSecureInfo->HashOutAddr    = (uint32_t)HashBuffer;
	pSecureInfo->KeyMode        = OP_BHDR_KEY;
	pSecureInfo->EncMode        = SYM_ECB;
	pSecureInfo->EncDir         = SYM_DECRYPT;
	pSecureInfo->CsuAddrIncMode = CSUDMA_DST_INCR | CSUDMA_SRC_INCR;
	pSecureInfo->BlockMode      = WHOLE_BLOCK;

	/// check secure info
	printf("Auth type :  %02x\r\n", pSecureInfo->AuthType);
	printf("Hash type :  %02x\r\n", pSecureInfo->HashType);
	printf("Enc type  :  %02x\r\n", pSecureInfo->EncType);
	printf("Enc mode  :  %02x\r\n", pSecureInfo->EncMode);
	printf("Key mode  :  %02x\r\n", pSecureInfo->KeyMode);

	/// partition data copy
	if((FsblInstancePtr->PrimaryBootDevice == ALFSBL_BOOTMODE_QSPI24) ||
	   (FsblInstancePtr->PrimaryBootDevice == ALFSBL_BOOTMODE_QSPI32)) {
		Status = FsblInstancePtr->DeviceOps.DeviceCopy(
				     SrcAddress,
					 LoadAddress,
					 Length,
					 pSecureInfo);
		if(ALFSBL_SUCCESS != Status) {
			goto END;
		}
#ifndef QSPI_XIP_THROUTH_CSU_DMA
		if(pSecureInfo->EncType != OP_ENCRYPT_NONE) {
			pSecureInfo->InputAddr  = LoadAddress;
			pSecureInfo->OutputAddr = LoadAddress;
			pSecureInfo->DataLength = Length;
			Status = AlFsbl_DecHash(pSecureInfo);
		}
		if(ALFSBL_SUCCESS != Status) {
			goto END;
		}
#endif
	}
	else if(FsblInstancePtr->PrimaryBootDevice == ALFSBL_BOOTMODE_NAND) {
		Status = FsblInstancePtr->DeviceOps.DeviceCopy(SrcAddress, LoadAddress, Length, NULL);
		if(ALFSBL_SUCCESS != Status) {
			goto END;
		}
		/// if encrypt enabled, do decrypt (and hash if necessary) through csu dma
		if(pSecureInfo->EncType != OP_ENCRYPT_NONE) {
			pSecureInfo->InputAddr  = LoadAddress;
			pSecureInfo->OutputAddr = LoadAddress;
			pSecureInfo->DataLength = Length;
			Status = AlFsbl_DecHash(pSecureInfo);
		}
		if(ALFSBL_SUCCESS != Status) {
			goto END;
		}
	}
	else if((FsblInstancePtr->PrimaryBootDevice == ALFSBL_BOOTMODE_SD)   ||
			(FsblInstancePtr->PrimaryBootDevice == ALFSBL_BOOTMODE_EMMC) ||
			(FsblInstancePtr->PrimaryBootDevice == ALFSBL_BOOTMODE_EMMC_RAW)) {
		Status = FsblInstancePtr->DeviceOps.DeviceCopy(SrcAddress, LoadAddress, Length, NULL);
		if(ALFSBL_SUCCESS != Status) {
			goto END;
		}
		/// if encrypt enabled, do decrypt (and hash if necessary) through csu dma
		if(pSecureInfo->EncType != OP_ENCRYPT_NONE) {
			pSecureInfo->InputAddr  = LoadAddress;
			pSecureInfo->OutputAddr = LoadAddress;
			pSecureInfo->DataLength = Length;
			Status = AlFsbl_DecHash(pSecureInfo);
		}
		if(ALFSBL_SUCCESS != Status) {
			goto END;
		}
	}
	else {
	}

	/// calculate data hash without csu dma
	if((pSecureInfo->EncType == OP_ENCRYPT_NONE) && (pSecureInfo->HashType != OP_HASH_NONE)) {
		printf("calculate hash\r\n");
		pSecureInfo->HashDataAddr = LoadAddress;
		Status = AlFsbl_Hash(pSecureInfo);
		if(Status != ALFSBL_SUCCESS) {
			goto END;
		}
	}

	/// read hash from boot image and check
	if((pSecureInfo->HashType != OP_HASH_NONE) && (PtHdr->HashDataOffset != 0)) {
		/// read hash from boot image
		//HashByteLen = (pSecureInfo->HashType == OP_HASH_SHA256) ? 32 : 16;
		Status = FsblInstancePtr->DeviceOps.DeviceCopy(
				     ImageOffsetAddress + PtHdr->HashDataOffset,
				     LoadAddress + PtHdr->PartitionLen,
				     32,
				     NULL);
		if(ALFSBL_SUCCESS != Status) {
			goto END;
		}

		/// compare hash
		Status = AlFsbl_CompareHash(
				     HashBuffer,
				     (uint8_t *)(LoadAddress + PtHdr->PartitionLen),
				     32);
		if(Status != ALFSBL_SUCCESS) {
			goto END;
		}
		printf("Hash check passed...\r\n");
	}

	if(pSecureInfo->AuthType != OP_AUTH_NONE) {
		printf("Auth\r\n");
		/// copy partition ac to local variate;
		PartitionAcOffset = PtHdr->AcOffset;
		printf("Partition AC offset: %08x\r\n", PartitionAcOffset);
		if(PartitionAcOffset == 0) {
			printf("ALFSBL_ERROR_PARTITION_HEADER_ACOFFSET\r\n");
			Status = ALFSBL_ERROR_PH_ACOFFSET;
			goto END;
		}
		else {
			printf("Copy Partition Header AC\r\n");
			Status = FsblInstancePtr->DeviceOps.DeviceCopy(
					     ImageOffsetAddress + PartitionAcOffset,
					     (PTRSIZE)PartitionAc,
					     ALFSBL_AUTH_BUFFER_SIZE,
					     NULL);
			if(Status != ALFSBL_SUCCESS) {
				goto END;
			}
		}
		/// initial auth parameters;
		pSecureInfo->PubKeyAddr = (uint32_t)(PartitionAc + ALAC_SPK_OFFSET);
		pSecureInfo->SignatureAddr = (uint32_t)(PartitionAc + ALAC_PART_SIGNATURE_OFFSET);
		Status = AlFsbl_Auth(pSecureInfo);
		if(Status != ALFSBL_SUCCESS) {
			goto END;
		}
		printf("Authenticat pass\r\n");
	}

	/// check decrypt result:
	ocmptr = (uint32_t *)(LoadAddress);
	for(i = 0; i < 4; i++) {
		printf("%08x\r\n", *ocmptr);
		ocmptr++;
	}


	/// update handoff values
	if((PtHdr->DestExecAddr) != 0xFFFFFFFFU) {
		printf("Update handoff values\r\n");
		HandoffNum = FsblInstancePtr->HandoffCpuNum;
		FsblInstancePtr->HandoffValues[HandoffNum].CpuSettings = DestCpu;
		FsblInstancePtr->HandoffValues[HandoffNum].HandoffAddress = PtHdr->DestExecAddr;
		FsblInstancePtr->HandoffCpuNum += 1;
	}

END:
	return Status;
}



static uint32_t AlFsbl_LoadPlPartition(AlFsblInfo *FsblInstancePtr, SecureInfo *pSecureInfo, uint32_t PartitionIdx)
{

	uint32_t i;
	uint32_t Status = 0;
	uint8_t  HashBuffer[32];
	uint8_t  HashData[32];
	uint32_t HashByteLen;
	uint32_t PartitionAcOffset;
	uint8_t  PartitionAc[ALFSBL_AUTH_BUFFER_SIZE];
	uint32_t ImageOffsetAddress;
	uint32_t BootDevice;
	uint8_t  DdrAvailable = FALSE;
	uint32_t BlockSizeMax;
	AlFsbl_PartitionHeader *PtHdr;
	PtHdr = &(FsblInstancePtr->ImageHeader.PartitionHeader[PartitionIdx]);
	ImageOffsetAddress = FsblInstancePtr->ImageOffsetAddress;

	/// pcap reset
	printf("PCAP RESET\r\n");
	REG32(CSU_PCAP_RESET) = 0;
	REG32(CSU_PCAP_RESET) = 1;

	printf("Set PCAP not enable\r\n");
	REG32(CSU_PCAP_ENABLE) = 0;

	printf("Set PCAP enable\r\n");
	REG32(CSU_PCAP_ENABLE) = 1;

	// check pl init done;
	Status = AlFsbl_CheckPlInitDone();
	if(Status != ALFSBL_SUCCESS) {
		goto END;
	}

	BlockSizeMax = FsblInstancePtr->DeviceOps.BlockSizeMax;
	printf("Boot device block size max: %x\r\n", BlockSizeMax);

	/// temp test: pl init and done:
	printf("PL init done\r\n");
	printf("cfg state: %08x\r\n", REG32(CRP_CFG_STATE));

	pSecureInfo->HashOutAddr    = (uint32_t)HashBuffer;
	pSecureInfo->KeyMode        = OP_BHDR_KEY;
	pSecureInfo->EncMode        = SYM_ECB;
	pSecureInfo->EncDir         = SYM_DECRYPT;
	//pSecureInfo->CsuAddrIncMode = CSUDMA_DST_INCR | CSUDMA_SRC_INCR;
	pSecureInfo->CsuAddrIncMode = CSUDMA_DST_NOINCR | CSUDMA_SRC_INCR;

	/// check secure info
	printf("Auth type :  %02x\r\n", pSecureInfo->AuthType);
	printf("Hash type :  %02x\r\n", pSecureInfo->HashType);
	printf("Enc type  :  %02x\r\n", pSecureInfo->EncType);
	printf("Enc mode  :  %02x\r\n", pSecureInfo->EncMode);
	printf("Key mode  :  %02x\r\n", pSecureInfo->KeyMode);

	BootDevice = FsblInstancePtr->PrimaryBootDevice;

	/// if hash enabled and data is not encrypted, read data first then do hash check
	/// if boot device is not xip-qspi, read data first then decrypt and hash check

	if(((pSecureInfo->HashType != OP_HASH_NONE) && (pSecureInfo->EncType == OP_ENCRYPT_NONE)) ||
	   ((BootDevice != ALFSBL_BOOTMODE_QSPI24) && (BootDevice != ALFSBL_BOOTMODE_QSPI32))) {
		if(DdrAvailable) {
			printf("to ddr in a whole block, then to pcap\r\n");
			/// todo, to ddr, whole block, then to pcap
		}
		else {
			//pSecureInfo->CsuAddrIncMode = CSUDMA_DST_INCR | CSUDMA_SRC_INCR;
			printf("to ocm in blocks, Block size: %d\r\n", BlockSizeMax);
			Status = AlFsbl_BitstreamDataTransfer(FsblInstancePtr, pSecureInfo, PartitionIdx, (uint32_t)ReadBuffer, BlockSizeMax);
			if(Status != ALFSBL_SUCCESS) {
				goto END;
			}
		}
	}
	else {
#ifdef QSPI_XIP_THROUTH_CSU_DMA
		printf("to pcap, whole block\r\n");
		//pSecureInfo->CsuAddrIncMode = CSUDMA_DST_NOINCR | CSUDMA_SRC_INCR;
		Status = AlFsbl_BitstreamDataTransfer(FsblInstancePtr, pSecureInfo, PartitionIdx, CSU_PCAP_WR_STREAM, 0);
		if(Status != ALFSBL_SUCCESS) {
			goto END;
		}
#else
		printf("to ocm in blocks, Block size: %d\r\n", BlockSizeMax);
		Status = AlFsbl_BitstreamDataTransfer(FsblInstancePtr, pSecureInfo, PartitionIdx, (uint32_t)ReadBuffer, BlockSizeMax);
		if(Status != ALFSBL_SUCCESS) {
			goto END;
		}
#endif
	}

	/// read hash from boot image and check
	if((pSecureInfo->HashType != OP_HASH_NONE) && (PtHdr->HashDataOffset != 0)) {
		/// read hash from boot image
		printf("read hash\r\n");
		//HashByteLen = (pSecureInfo->HashType == OP_HASH_SHA256) ? 32 : 16;
		Status = FsblInstancePtr->DeviceOps.DeviceCopy(
				     ImageOffsetAddress + PtHdr->HashDataOffset,
					 (uint32_t)HashData,
				     32,
				     NULL);
		if(ALFSBL_SUCCESS != Status) {
			goto END;
		}

		/// compare hash
		Status = AlFsbl_CompareHash(
				     HashBuffer,
					 HashData,
				     32);
		if(Status != ALFSBL_SUCCESS) {
			goto END;
		}
		printf("Hash check passed...\r\n");
	}

	/// auth check if necessary
	if(pSecureInfo->AuthType != OP_AUTH_NONE) {
		printf("auth\r\n");
		/// copy partition ac to local variate;
		PartitionAcOffset = PtHdr->AcOffset;
		printf("Partition AC offset: %08x\r\n", PartitionAcOffset);
		if(PartitionAcOffset == 0) {
			printf("ALFSBL_ERROR_PARTITION_HEADER_ACOFFSET\r\n");
			Status = ALFSBL_ERROR_PH_ACOFFSET;
			goto END;
		}
		else {
			printf("Copy Partition Header AC\r\n");
			Status = FsblInstancePtr->DeviceOps.DeviceCopy(
					     ImageOffsetAddress + PartitionAcOffset,
					     (PTRSIZE)PartitionAc,
					     ALFSBL_AUTH_BUFFER_SIZE,
					     NULL);
			if(Status != ALFSBL_SUCCESS) {
				goto END;
			}
		}
		/// initial auth parameters;
		pSecureInfo->PubKeyAddr = (uint32_t)(PartitionAc + ALAC_SPK_OFFSET);
		pSecureInfo->SignatureAddr = (uint32_t)(PartitionAc + ALAC_PART_SIGNATURE_OFFSET);
		Status = AlFsbl_Auth(pSecureInfo);
		if(Status != ALFSBL_SUCCESS) {
			goto END;
		}
		printf("Authenticate pass\r\n");
	}

	/// temp test: pl init and done:
	printf("cfg state before progdone: %08x\r\n", REG32(CRP_CFG_STATE));



	/// program_done
	Status = ALFsbl_BitStreamProgDone();
	if(ALFSBL_SUCCESS != Status) {
		goto END;
	}

	/// temp test: pl init and done:
	printf("cfg state after progdone: %08x\r\n", REG32(CRP_CFG_STATE));

	/// check cfg state after bitstream loaded
	if((REG32(CRP_CFG_STATE)) != 7) {
		Status = ALFSBL_ERROR_PL_CFG_STATE_ERROR & (REG32(CRP_CFG_STATE) | 0xFFFFFFF8UL);
		goto END;
	}

	/// set PCAP not enable, to make the signal to config model not change
	REG32(CSU_PCAP_ENABLE) = 0;


END:
	return Status;
}




static uint32_t AlFsbl_BitstreamDataTransfer(AlFsblInfo *FsblInstancePtr, SecureInfo *pSecureInfo,
		                                     uint32_t PartitionIdx, uint32_t DestAddr,
										     uint32_t BlockSizeMax)
{
	uint32_t Status = 0;
	AlFsbl_PartitionHeader *PtHdr;
	uint32_t ImageOffsetAddress;
	uint32_t SrcAddress;
	uint32_t Length;
	uint32_t BlockLength;
	uint32_t BlockSrcAddr;
	uint32_t BlockDestAddr;
	uint32_t BlockCnt = 0;

	PtHdr = &(FsblInstancePtr->ImageHeader.PartitionHeader[PartitionIdx]);
	ImageOffsetAddress = FsblInstancePtr->ImageOffsetAddress;
	SrcAddress = FsblInstancePtr->ImageOffsetAddress + PtHdr->PartitionOffset;
	Length = PtHdr->PartitionLen;

	printf("partition src address      : 0x%08x\r\n", SrcAddress);
	printf("partition load dest address: 0x%08x\r\n", DestAddr);
	printf("partition length           : 0x%08x\r\n", Length);


	BlockSrcAddr  = SrcAddress;
	BlockDestAddr = DestAddr;
	if(BlockSizeMax == 0) {
		pSecureInfo->BlockMode = WHOLE_BLOCK;
		printf("whole block\r\n");
		BlockLength = Length;
	}
	else if(Length > BlockSizeMax) {
		pSecureInfo->BlockMode = FIRST_BLOCK;
		printf("first block\r\n");
		BlockLength = BlockSizeMax;
	}
	else {
		pSecureInfo->BlockMode = WHOLE_BLOCK;
		printf("whole block\r\n");
		BlockLength = Length;
	}

	while(Length != 0) {
		/// data transfer
		if(((BlockCnt + 1) % 100) == 0) {
			printf("Blk num: %d\r\n", BlockCnt);
		}

		if(DestAddr == CSU_PCAP_WR_STREAM) {
			/// transfer to pcap, only when boot device is xip-qspi and not hash only
			Status = FsblInstancePtr->DeviceOps.DeviceCopy(
					     BlockSrcAddr,
						 BlockDestAddr,
						 BlockLength,
						 pSecureInfo);
			if(Status != ALFSBL_SUCCESS) {
				goto END;
			}
		}
		else {
			/// transfer to a buffer, if boot device is none-xip-qspi, sd/emmc, nand, or xip-qspi with hash only
			/// step 1: transfer to buffer,
			Status = FsblInstancePtr->DeviceOps.DeviceCopy(
					     BlockSrcAddr,
						 BlockDestAddr,
						 BlockLength,
						 NULL);
			if(Status != ALFSBL_SUCCESS) {
				goto END;
			}

			/// step 2: transfer to pcap
			/// if enc enabled, do decrypt
			pSecureInfo->HashDataAddr = BlockDestAddr;
			pSecureInfo->InputAddr    = BlockDestAddr;
			pSecureInfo->OutputAddr   = CSU_PCAP_WR_STREAM;
			pSecureInfo->DataLength   = BlockLength;
			Status = AlFsbl_DecHash(pSecureInfo);

			/// step 3: if hash enabled without enc, calculate hash
			if((pSecureInfo->EncType == OP_ENCRYPT_NONE) &&
			   (pSecureInfo->HashType != OP_HASH_NONE)) {
				//printf("calculate hash\r\n");
				pSecureInfo->HashDataAddr = BlockDestAddr;
				Status = AlFsbl_Hash(pSecureInfo);
				if(Status != ALFSBL_SUCCESS) {
					goto END;
				}
			}
		}

		if(BlockSizeMax == 0)
			goto END;

		BlockSrcAddr  += BlockLength;
		Length        -= BlockLength;

		pSecureInfo->BlockMode = (Length > BlockSizeMax) ? MIDDLE_BLOCK : LAST_BLOCK;
		BlockLength = (Length > BlockSizeMax) ? BlockSizeMax : Length;
		BlockCnt++;
	}

END:
	return Status;
}




#define  RPU_MTIMER_COUNTER64     (0x68020000)
#define  RPU_MTIMER_COUNTER64_LOW (0x68020000)
#define  RPU_MTIMER_COUNTER64_HI  (0x68020004)

uint32_t AlFsbl_CheckPlInitDone(void)
{
	uint32_t Status = ALFSBL_SUCCESS;
	volatile uint64_t StartTime;
	volatile uint64_t CurrTime;
	uint32_t InitDone;
	uint32_t cnt;

#if __riscv
	StartTime = REG32(RPU_MTIMER_COUNTER64);
#else
	StartTime = get_SystickTimer();
	printf("start time: %x\n", StartTime);
#endif

	do {
		/// if pl init done not asserted in 90 seconds, report an error
#if __riscv
		if((REG32(RPU_MTIMER_COUNTER64) - StartTime ) > (90 * 10 * 1000 * 1000)) {
			Status = ALFSBL_ERROR_PL_INIT_TIMEOUT;
			goto END;
		}
#else
		CurrTime = get_SystickTimer();
		printf("current time: %x\n", CurrTime);
		if((CurrTime - StartTime) > (90 * 2 * 1000 * 1000)) {
			Status = ALFSBL_ERROR_PL_INIT_TIMEOUT;
			goto END;
		}
#endif

		InitDone = REG32(CRP_CFG_STATE) & CRP_CFG_STATE_MSK_PL2PS_INITN;

	} while(InitDone != CRP_CFG_STATE_MSK_PL2PS_INITN);

END:
	return Status;

}


uint32_t ALFsbl_BitStreamProgDone(void)
{
	uint32_t Status;
	uint32_t ProgDone[3] = {0x90300002, 0x00000005, 0x1655e833};
	uint32_t BitStreamNoop = 0x80000000;

	REG32(CSU_PCAP_WR_STREAM) = ProgDone[0];
	REG32(CSU_PCAP_WR_STREAM) = ProgDone[1];
	REG32(CSU_PCAP_WR_STREAM) = ProgDone[2];

	printf("\n");

	Status = AlFsbl_CsuDmaCopy(
			     (uint32_t)(&BitStreamNoop),
				 CSU_PCAP_WR_STREAM,
				 8192,   /// 2048 words of noop
				 (CSUDMA_DST_NOINCR | CSUDMA_SRC_NOINCR));

	return Status;
}



void AlFsbl_PrintPartitionHeaderInfo(AlFsbl_PartitionHeader *PtHdr)
{
	printf("\nPartition Header Infomation:\n");
	printf("Partition Length            : 0x%08x\r\n", PtHdr->PartitionLen);
	printf("Extracted Partition Length  : 0x%08x\r\n", PtHdr->ExtractedPartitionLen);
	printf("Total Partition Length      : 0x%08x\r\n", PtHdr->TotalPartitionLen);
	printf("Next Partition Header Offset: 0x%08x\r\n", PtHdr->NextPartHdrOffset);
	printf("Dest Execution Address      : 0x%08x\r\n", PtHdr->DestExecAddr);
	printf("Dest Load Address           : 0x%08x\r\n", PtHdr->DestLoadAddr);
	printf("Partition Offset            : 0x%08x\r\n", PtHdr->PartitionOffset);
	printf("Partition Attribute         : 0x%08x\r\n", PtHdr->PartitionAttribute);
	printf("Hash Data offset            : 0x%08x\r\n", PtHdr->HashDataOffset);
	printf("AC Offset                   : 0x%08x\r\n", PtHdr->AcOffset);
	printf("Partition Header Checksum   : 0x%08x\r\n", PtHdr->PartiHdrChecksum);
	printf("\r\n");

	return;
}

