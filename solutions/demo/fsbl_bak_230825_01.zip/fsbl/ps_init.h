/*
 * alfsbl_psu_init.h
 *
 *  Created on: Dec 10, 2022
 *      Author: xuqingsong
 */

#ifndef PS_INIT_H_
#define PS_INIT_H_

#include <stdint.h>

uint32_t ps_init(void);


#endif /* PS_INIT_H_ */
